import React from "react";

const CreateUser = React.createContext("english");
export default CreateUser;