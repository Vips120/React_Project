import React from "react";
const Templateform = () => {
    return (
         <div>
              
   </div>
    )
};

export default Templateform;