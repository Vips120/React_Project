import React, { Component } from "react";
import Header from "./navigation.component";

class Navigation extends Component {

    render() {
        return (
            <React.Fragment>
                <Header/>
           </React.Fragment>
        )
    }
};

export default Navigation;

