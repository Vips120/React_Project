import React from "react";
const Notfound = (props) => {
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                         <h1>NOT FOUND</h1>
                </div>
          </div>
        </div>
    )
};

export default Notfound;
