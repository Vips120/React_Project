import React, { Component } from "react";

class Admin extends Component {
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <h1>Admin SECTION</h1>
                    </div>
                </div>
            </div>
        )
    }
}

export default Admin;