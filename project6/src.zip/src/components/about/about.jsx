import React, { Component } from "react";

class About extends Component {
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <h1>About SECTION</h1>
                    </div>
                </div>
            </div>
        )
    }
}

export default About;