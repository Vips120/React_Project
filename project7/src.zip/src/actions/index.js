export const SelectedSong = (song) => {
    return { type: "SELECTED_SONG", payload: song }
};