import React from 'react';
import reactDOM from "react-dom";
import App from './app';
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/font-awesome/css/font-awesome.min.css";

reactDOM.render(<App username="vipul" />, document.getElementById("root"));