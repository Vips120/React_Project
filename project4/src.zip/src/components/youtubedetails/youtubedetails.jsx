import React from "react";
const YDetails = ({details}) => {
    if (!details) { return null;}
    return (
        <div className="container">
         <div className="row">
                <div className="col-md-8">
                    <iframe src={`https://www.youtube.com/embed/${details}`}></iframe>
                </div>
            </div> 
        </div>
    )
};

export default YDetails;