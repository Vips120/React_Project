import React, { Component } from 'react';
import Postlist from './components/postlist';


class App extends Component {
  render() {
    return (
      <div className="container">
             <Postlist/>
            </div>
    );    
  }

}

export default App;
